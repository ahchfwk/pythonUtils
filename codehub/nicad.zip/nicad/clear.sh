#!/bin/bash
rm -f /home/fdse/fwk/SourcererCC/clone-detector/Detection.file
rm -f /home/fdse/fwk/SourcererCC/clone-detector/input/bookkeping/headers.file
rm -f /home/fdse/fwk/SourcererCC/clone-detector/input/query/tokens.file
rm -rf /home/fdse/fwk/SourcererCC/clone-detector/input/dataset
mkdir /home/fdse/fwk/SourcererCC/clone-detector/input/dataset
